 NL_Backprojection 1.0

 Dec. 25, 2009

---------------------------------------------------------------------------
Copyright (2009): Weisheng Dong, Lei Zhang, Guangming Shi, and Xiaolin Wu

---------------------------------------------------------------------------


 The code is for the work:

 Weisheng Dong, Lei Zhang, Guangming Shi, and Xiaolin Wu,
 
 "Nonlocal back-projection for adaptive image enlargement", 

 in Proc. ICIP 2009.


 You can run the exe file: NL_Backprojection.exe by the following commandline:


 >>NL_Backprojection  Input\LR_foreman.pgm  Foreman_NLIBP.pgm

 where "Input\LR_foreman.pgm" is the input LR image, "Foreman_NLIBP.pgm" is the file name of the reconstructed HR image.


 In the case that you have the original image, the exe can also compute the PSNR value of the reconstructed HR image 
 by running the exe file as follows:

 >>NL_Backprojection  Input\LR_foreman.pgm  Foreman_NLIBP.pgm  Input\Foreman.pgm




 Contact: wsdong@mail.xidian.edu.cn  (Weisheng Dong)
	  cslzhang@comp.polyu.edu.hk (Lei Zhang)