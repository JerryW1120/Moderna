/* Nonlocal iterative back projection for image super resolution
* For scaling factor of 2
* 
* Dec. 2008, Weisheng Dong
* Revised Nov. 2009
*
* Reference:
* Weisheng Dong, Lei Zhang, Guangming Shi, and Xiaolin Wu, "Nonlocal back-projection for adaptive 
* image enlargement", in Proc. ICIP 2009.
*
* For any question, contact me via: wsdong@mail.xidian.edu.cn
*/

#define  MAX_FLOAT    100000
#define  N            15
#define  T            30
#define  WSIZE        7
#define  SAD_THRESH   10
#define  H            0.6


#define  BLK_W        3
#define  BLK_H        3
#define  MAX_ITER     20  

#define  KER_WIDTH    5
#define  KER_HEIGHT   5



// Gaussian filter with standard deviation of 1.0
float g_psf[ 25 ]  = {
	0.0030,    0.0133,    0.0219,    0.0133,    0.0030,
	0.0133,    0.0596,    0.0983,    0.0596,    0.0133,
	0.0219,    0.0983,    0.1621,    0.0983,    0.0219,
	0.0133,    0.0596,    0.0983,    0.0596,    0.0133,
	0.0030,    0.0133,    0.0219,    0.0133,    0.0030
};


int Get_image_size          ( char *input_frame, int *width, int *height );
int  Read_image             ( char *fname, unsigned char *pdat );
double Cal_psnr             ( unsigned char *pOrig, unsigned char *pImg, int width, int height );
void Write2PGM              ( unsigned char *pImg, int width, int height, char *fname );
int read_header             ( FILE *fin, int *widthp, int *heightp, int *maxvalp, int *comp);

void Downsampling           ( unsigned char *lr_im, unsigned char *hr_im, int scale, int width, int height, float *lp_filter );
void Bicubic                ( unsigned char *pLR, unsigned char *pHR, int scale, int lwidth, int lheight );

void NL_filtering           ( unsigned char *hr_img, int width, int height, int *pmvx[ N ], int *pmvy[ N ], float *pmse[ N ] );
void Fast_Motion_estimation ( unsigned char *pre_fra, unsigned char *cur_fra, int width, int height, int *mvx[ N ], int *mvy[ N ], float *pmse[ N ] );
void Data_fusion            ( unsigned char *phr_Fra, unsigned char pcurFra, unsigned char *obs, float *mse, int n_ref );
inline float Cal_SAD_New    ( unsigned char *cur_fra, int x, int y, unsigned char *ref_fra, int cx, int cy, int width, int height );


void NL_Backprojection      ( unsigned char *hr_im, int width, int height, unsigned char *ori_im, int *pmvx[ N ], int *pmvy[ N ], float *pmse[ N ], int );
void Add_error              ( float *im, float *err_im, int width, int height, float lambda );
double Norm2                ( float *im, int width, int height );
double Diff_Norm2           ( float *im1, float *im2, int width, int height );
void Float2uchar            ( float *f_im, unsigned char *uim, int width, int height );
void Blurring               ( float *d_im, float *im, int width, int height );
void Error_image            ( float *err_im, float *d_im, unsigned char *im, int width, int height, int *pmvx[ N ], int *pmvy[ N ], float *pmse[ N ] );
void Bicubic_float          ( float *im, int width, int height );
inline void Data_fusion_float    ( float *phr_Fra, float pcurFra, float *obs, float *mse, int n_ref );

