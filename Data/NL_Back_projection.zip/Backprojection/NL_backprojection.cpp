/* Nonlocal iterative back projection for image super resolution
* For scaling factor of 2
* 
* Dec. 2008, Weisheng Dong
* Revised Dec. 25, 2009
*
* Reference:
* Weisheng Dong, Lei Zhang, Guangming Shi, and Xiaolin Wu, "Nonlocal back-projection for adaptive 
* image enlargement", in Proc. ICIP 2009.
*
* For any question, contact me via: wsdong@mail.xidian.edu.cn
*/
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <conio.h>
#include <math.h>
#include <time.h>
#include <assert.h>
#include "NL_Backprojection.h"


int main(int argc, char* argv[])
{
	int                  i, j, width, height, maxval, comp, lwidth, lheight, row, col, scale;
	unsigned char        *hr_im, *ori_im, *lr_im;
	unsigned char        temp;
	double               psnr1;
	FILE                 *fp;
	int                  *g_mvx[ N ], *g_mvy[ N ];
	float                *g_mse[ N ];


	if( argc<3 )
	{
		printf("Usage: NL_Backprojection  LR_image(pgm)  HR_image(pgm)  [Original_image(pgm)]  \n");
		return 1;
	}
	scale    =  2;


	if ( Get_image_size( argv[1], &lwidth, &lheight ) )
	{
		printf( "Can not read %s", argv );
		return 1;
	}


	width       =  lwidth*scale;
	height      =  lheight*scale;
	hr_im       =  (unsigned char*) malloc( sizeof(char)*width*height );
	ori_im      =  (unsigned char*) malloc( sizeof(char)*width*height );
	lr_im       =  (unsigned char*) malloc( sizeof(char)*lwidth*lheight );


	//Read_image( argv[3], ori_im );
	//Downsampling( lr_im, ori_im, scale, width, height, g_psf );
	//Write2PGM( lr_im, width/scale, height/scale, argv[1] );


	Read_image( argv[1], lr_im );


	printf( "Start to processing %s\n", argv[1] );

	Bicubic( lr_im, hr_im, scale, lwidth, lheight );
	Write2PGM( hr_im, width, height, "Bic_image.pgm" );


	if ( argc >3 )
	{
		Read_image( argv[3], ori_im );
		printf( "Bicubic, PSNR = %f\n", Cal_psnr( ori_im, hr_im, width, height ) );
	}



	for ( i = 0; i < N; i ++ )
	{
		g_mvx[ i ]    =  (int*) malloc( sizeof(int)*width*height );
		g_mvy[ i ]    =  (int*) malloc( sizeof(int)*width*height );
		g_mse[ i ]    =  (float*) malloc( sizeof(int)*width*height );
	}

	NL_filtering( hr_im, width, height, g_mvx, g_mvy, g_mse );

	NL_Backprojection( hr_im, width, height, ori_im, g_mvx, g_mvy, g_mse, argc );

	if ( argc > 3 )
	{
		printf( "After Backprojection, PSNR = %f\n", Cal_psnr( ori_im, hr_im, width, height ) );
	}


	printf("\nWrite to file: %s.\n",argv[2]); 
	Write2PGM( hr_im, width, height, argv[2] );


	free( hr_im );
	free( ori_im );
	free( lr_im );

	for ( i = 0; i < N; i ++ )
	{
		free( g_mvx[ i ] );
		free( g_mvy[ i ] );
		free( g_mse[ i ] );
	}
	return 0;
}



void NL_Backprojection( unsigned char *hr_im, int width, int height, unsigned char *ori_im, int *pmvx[ N ], int *pmvy[ N ], float *pmse[ N ], int argc )
{
	int              iter, row, col, offset;
	float            *b_im, *err_im, *im, *pre_im;
	float            lambda   = 0.4, delta, pix, obs[ N ], mse[ N ];
	char             fname[100];
	unsigned char    *tmp_im;


	im         =  (float*) malloc( sizeof(float)*width*height );
	pre_im     =  (float*) malloc( sizeof(float)*width*height );
	b_im       =  (float*) malloc( sizeof(float)*width*height );
	err_im     =  (float*) malloc( sizeof(float)*width*height );
	tmp_im     =  (unsigned char*) malloc( sizeof(char)*width*height );

	for ( row = 0; row < height; row ++ )
	{
		for ( col = 0; col < width; col ++ )
		{
			im[ row*width+col ]    =  hr_im[ row*width+col ];
		}
	} 
	memcpy( pre_im, im, sizeof(float)*width*height );


	for ( iter = 0; iter < MAX_ITER; iter ++ )
	{
		Blurring( b_im, im, width, height );

		Error_image( err_im, b_im, hr_im, width, height, pmvx, pmvy, pmse );

		Add_error( im, err_im, width, height, lambda );

		delta   =  Diff_Norm2( pre_im, im, width, height );
		printf( "The %d th iteration, delta = %f,  ", iter, delta );

		memcpy( pre_im, im, sizeof(float)*width*height );


		if ( argc>3 )
		{
			Float2uchar( im, tmp_im, width, height );
			printf( "PSNR = %f", Cal_psnr( ori_im, tmp_im, width, height ) );
		}
		printf( "\n" );

		//sprintf( fname, "temp_%d.pgm", iter );
		//Write2PGM( tmp_im, width, height, fname );
		//Fast_Motion_estimation( tmp_im, tmp_im, width, height, pmvx, pmvy, pmse );
	}

	Float2uchar( im, tmp_im, width, height );
	memcpy( hr_im, tmp_im, sizeof(char)*width*height );

	free( im );
	free( b_im );
	free( pre_im );
	free( err_im );
	free( tmp_im );
}



void Add_error( float *im, float *err_im, int width, int height, float lambda )
{
	int               row, col, offset;


	for ( row = 0; row < height; row ++ )
	{
		for ( col = 0; col < width; col ++ )
		{

			offset         =  row*width+col;
			im[ offset ]   =  im[ offset ] - ( err_im[ offset ] * lambda );
		}
	}
}



double Norm2( float *im, int width, int height )
{
	register int          row, col, offset;
	register double       sum = 0;


	for ( row = 0; row <height; row ++ )
	{
		for ( col = 0; col < width; col ++ )
		{
			offset    =  row*width+col;
			sum      +=  im[ offset ] * im[ offset ];
		}
	}

	return ( sum/width/height );
}


double Diff_Norm2( float *im1, float *im2, int width, int height )
{
	register int          row, col, offset;
	register double       sum = 0;


	for ( row = 0; row <height; row ++ )
	{
		for ( col = 0; col < width; col ++ )
		{
			offset    =  row*width+col;
			sum      +=  (im1[ offset ]-im2[ offset ]) * (im1[ offset ] - im2[ offset ]);
		}
	}

	return ( sum/width/height );

}



void Float2uchar( float *f_im, unsigned char *uim, int width, int height )
{
	int              row, col, offset;
	float            pix;


	for ( row = 0; row < height; row ++ )
	{
		for ( col = 0; col < width; col ++ )
		{
			offset            =  row*width+col;
			pix               =  (f_im[ offset ]<0) ? 0 : ( (f_im[offset]>255) ? 255 : f_im[offset] );
			uim[ offset ]     =  (unsigned char) ( pix+0.5 );
		}
	}
}



void Blurring( float *d_im, float *im, int width, int height )
{
	int         row, col, m, k, row1, col1, cnt;
	int         k_width, k_height;
	float       sum;


	k_width    =  KER_WIDTH;
	k_height   =  KER_HEIGHT;

	for ( row = 0; row < height; row ++  )
	{
		for ( col = 0; col < width; col ++ )
		{
			sum   =  0;

			for ( m = 0, cnt = 0; m < k_height; m ++ )
			{
				row1    =  row - ( k_height>>1 ) + m;

				if ( row1<0 )               row1   =  -row1;
				else if ( row1>=height )    row1   =  2*(height-1)-row1;

				for ( k = 0; k < k_width; k ++ )
				{
					col1    =  col - ( k_width>>1 ) + k;

					if ( col1<0 )              col1   =  -col1;
					else if ( col1>=width )    col1   =  2*(width-1)-col1;

					sum   +=  im[ row1*width+col1 ]*g_psf[ cnt++ ];
				}
			}

			d_im[ row*width+col ]    =  sum;
		}
	}
}



void Out_image( float *f_im, int width, int height, char *fname )
{
	unsigned char         *tmp_im;
	int                   row, col;


	tmp_im   =  (unsigned char*) malloc( sizeof(char)*width*height ); 

	for ( row = 0; row < height; row ++ )
	{
		for ( col = 0; col < width; col ++ )
		{
			tmp_im[ row*width+col ]    =  (unsigned char) ( f_im[ row*width+col ] + 128 );
		}
	}

	Write2PGM( tmp_im, width, height, fname );

	free( tmp_im );
}



void Error_image( float *err_im, float *d_im, unsigned char *im, int width, int height, int *pmvx[ N ], int *pmvy[ N ], float *pmse[ N ] )
{
	int                   row, col, m, k, row1, col1, cnt, offset;
	int                   k_width, k_height, i, mx, my;
	float                 sum, *tmp, obs[ N ], mse[ N ];	


	tmp     =  (float*) malloc( sizeof(float)*width*height );
	memset( tmp, 0, sizeof(float)*width*height );	


	for ( row = 0; row < height; row +=2 )
	{
		for ( col = 0; col < width; col +=2 )
		{
			offset   =  row*width+col;

			tmp[ offset ]   =  d_im[ offset ] - (float)(im[ offset ]);
		}
	}

	Bicubic_float( tmp, width, height );
	memcpy( err_im, tmp, sizeof(float)*width*height );

	Out_image( tmp, width, height, "Error_image.pgm" );



	for ( row = (WSIZE/2); row < (height-WSIZE/2); row ++ )
	{
		for ( col = (WSIZE/2); col < (width-WSIZE/2); col ++ )
		{
			if ( (row%2==0) && (col%2==0) )     continue;


			for ( i = 0; i < N; i++ )
			{
				mse[ i ]    =  pmse[ i ][ row*width+col ];
				mx          =  pmvx[ i ][ row*width+col ];
				my          =  pmvy[ i ][ row*width+col ];

				row1        =  row + my;
				col1        =  col + mx;

				if ( row1<0 )             row1   =  -row1;
				else if ( row1>=height )  row1   =  2*(height-1)-row1;

				if ( col1<0 )             col1   =  -col1;
				else if ( col1>=width )   col1   =  2*(width-1)-col1;

				obs[ i ]    =  tmp[ row1*width + col1 ];				
			}

			Data_fusion_float( &err_im[row*width+col], tmp[ row*width+col ], obs, mse, N );
		}
	}

	Out_image( err_im, width, height, "Error_image_NLM.pgm" );


	free( tmp );	
}



void NL_filtering( unsigned char *hr_img, int width, int height, int *pmvx[ N ], int *pmvy[ N ], float *pmse[ N ] )
{
	int                  idx, i;
	float                mse[ N ];
	int                  row, col, mx, my, cnt, iter, row1, col1;
	unsigned char        obs[ N ], *int_img;


	int_img     =  (unsigned char*) malloc( sizeof(char)*width*height );

	for ( iter = 0; iter < 1; iter ++ )
	{
		memcpy( int_img, hr_img, sizeof(char)*width*height );

		for ( i = 0; i < N; i ++ )
		{
			memset( pmvx[ i ], 0, sizeof(int)*width*height );
			memset( pmvy[ i ], 0, sizeof(int)*width*height );
			memset( pmse[ i ], 0, sizeof(float)*width*height );
		}

		Fast_Motion_estimation( int_img, int_img, width, height, pmvx, pmvy, pmse );


		for ( row = (WSIZE/2); row < (height-WSIZE/2); row ++ )
		{
			for ( col = (WSIZE/2); col < (width-WSIZE/2); col ++ )
			{
				if ( (row%2==0) && (col%2==0) )   continue;

				for ( i = 0; i < N; i++ )
				{
					mse[ i ]    =  pmse[ i ][ row*width+col ];
					mx          =  pmvx[ i ][ row*width+col ];
					my          =  pmvy[ i ][ row*width+col ];					
					row1        =  row + my;
					col1        =  col + mx;

					if ( row1<0 )             row1   =  -row1;
					else if ( row1>=height )  row1   =  2*(height-1)-row1;

					if ( col1<0 )             col1   =  -col1;
					else if ( col1>=width )   col1   =  2*(width-1)-col1;

					obs[ i ]    =  int_img[ row1*width+col1 ];					
				}

				Data_fusion( &hr_img[row*width+col], int_img[ row*width+col ], obs, mse, N );
			}
		}
	}

	free( int_img );
}



void Fast_Motion_estimation( unsigned char *pre_fra, unsigned char *cur_fra, int width, int height, int *mvx[ N ], int *mvy[ N ], float *pmse[ N ] )
{
	register int      y_idx, x_idx, y_num, x_num, y, x, y_up, y_down, x_left, x_right, s, imx[ N ], imy[ N ], y_offset, x_offset;
	unsigned char     a_block[ WSIZE*WSIZE ], r_block[ WSIZE*WSIZE ];
	register float    min_mse[ N ], tmp;
	register int      idx, i, j, cx, cy, ix, iy, offset, m, k, x1, y1;


	s     =  2*T+1;
	y_num     =  height;
	x_num     =  width;


	// For the pixels in Odd rows, Odd cols
	y_offset    =  WSIZE/2;
	y_offset    =  ( (y_offset%2)==0 ) ? (y_offset+1) : y_offset;
	x_offset    =  WSIZE/2;
	x_offset    =  ( (x_offset%2)==0 ) ? (x_offset+1) : x_offset;

	for ( y_idx = y_offset; y_idx < height; y_idx  += (BLK_H<<1) )
	{
		y        =  y_idx;
		y_up     =  ( (y - (WSIZE-1)/2 )<T ) ? (-y + (WSIZE-1)/2 ) : (-T);
		y_down   =  ( (height-y-WSIZE/2) < T ) ? ( height-y-WSIZE/2 ) : T;

		for ( x_idx = x_offset; x_idx < width; x_idx  += (BLK_W<<1) )
		{
			x         =  x_idx;
			x_left    =  ( ( x- (WSIZE-1)/2 ) <T ) ? ( -x + (WSIZE-1)/2 ) : (-T);
			x_right   =  ( ( width - x - WSIZE/2 ) < T ) ? ( width - x - (WSIZE/2) ) : T;


			for ( i = 0; i < N; i++ )
			{
				min_mse[i]   =  MAX_FLOAT;
				imx[ i ]     =  0;
				imy[ i ]     =  0;
			}

			for ( iy = y_up; iy < y_down; iy++  )
			{
				for ( ix = x_left; ix < x_right; ix ++ )
				{
					cx    =  ix + x;
					cy    =  iy + y;

					if ( !((cx%2==0)&&(cy%2==0)) )   continue;

					tmp   =  Cal_SAD_New( cur_fra, x, y, pre_fra, cx, cy, width, height );

					for ( i = 0; i < N; i ++ )
					{
						if ( min_mse[i]>tmp )
						{
							for ( j = N-1; j>i; j-- )
							{
								min_mse[ j ]   =  min_mse[ j-1 ];
								imx[ j ]       =  imx[ j-1 ];
								imy[ j ]       =  imy[ j-1 ];
							}
							min_mse[ i ]       =  tmp;
							imx[ i ]           =  ix;
							imy[ i ]           =  iy;
							break;
						}
					}
				}
			}

			offset   =  y_idx*x_num+x_idx;
			for ( i = 0; i < N; i ++ )
			{
				mvx[ i ][ offset ]    =  imx[ i ];
				mvy[ i ][ offset ]    =  imy[ i ];
				pmse[ i ][ offset ]   =  min_mse[ i ];
			}

			for ( m = 0; m < BLK_H; m++ )
			{
				y1   =  y + (m<<1) - ( BLK_H-1 );
				if ( y1<0 || y1>=height )   continue;

				for ( k = 0; k < BLK_W; k++ )
				{
					x1   =  x + (k<<1) - ( BLK_W-1 );
					if ( (x1<0 || x1>=width) || ( x1==x && y1==y ) )   continue;

					offset   =  y1*width + x1;

					for ( i = 0; i < N; i ++ )
					{
						if ( min_mse[i] == MAX_FLOAT ) 
						{
							break;
						}

						mvx[ i ][ offset ]   =  imx[ i ];
						mvy[ i ][ offset ]   =  imy[ i ];

						cx    =  x1 + imx[i];
						cy    =  y1 + imy[i];

						pmse[ i ][ offset ]   =  Cal_SAD_New( cur_fra, x1, y1, pre_fra, cx, cy, width, height );
					}
				}
			}
		}
	}



	// For the pixels in the Even rows, Odd cols
	y_offset    =  WSIZE/2;
	y_offset    =  ( (y_offset%2)==1 ) ? (y_offset+1) : y_offset;
	x_offset    =  WSIZE/2;
	x_offset    =  ( (x_offset%2)==0 ) ? (x_offset+1) : x_offset;

	for ( y_idx = y_offset; y_idx < height; y_idx   +=  (BLK_H<<1) )
	{
		y        =  y_idx;
		y_up     =  ( (y - (WSIZE-1)/2 )<T ) ? (-y + (WSIZE-1)/2 ) : (-T);
		y_down   =  ( (height-y-WSIZE/2) < T ) ? ( height-y-WSIZE/2 ) : T;

		for ( x_idx = x_offset; x_idx < width; x_idx  += (BLK_W<<1) )
		{
			x         =  x_idx;
			x_left    =  ( ( x- (WSIZE-1)/2 ) <T ) ? ( -x + (WSIZE-1)/2 ) : (-T);
			x_right   =  ( ( width - x - WSIZE/2 ) < T ) ? ( width - x - (WSIZE/2) ) : T;


			for ( i = 0; i < N; i++ )
			{
				min_mse[i]   =  MAX_FLOAT;
				imx[ i ]     =  0;
				imy[ i ]     =  0;
			}

			for ( iy = y_up; iy < y_down; iy++  )
			{
				for ( ix = x_left; ix < x_right; ix ++ )
				{
					cx    =  ix + x;
					cy    =  iy + y;

					if ( !((cx%2==0)&&(cy%2==0)) )   continue;

					tmp   =  Cal_SAD_New( cur_fra, x, y, pre_fra, cx, cy, width, height );

					for ( i = 0; i < N; i ++ )
					{
						if ( min_mse[i]>tmp )
						{
							for ( j = N-1; j>i; j-- )
							{
								min_mse[ j ]   =  min_mse[ j-1 ];
								imx[ j ]       =  imx[ j-1 ];
								imy[ j ]       =  imy[ j-1 ];
							}
							min_mse[ i ]       =  tmp;
							imx[ i ]           =  ix;
							imy[ i ]           =  iy;
							break;
						}
					}
				}
			}

			offset   =  y_idx*x_num+x_idx;
			for ( i = 0; i < N; i ++ )
			{
				mvx[ i ][ offset ]    =  imx[ i ];
				mvy[ i ][ offset ]    =  imy[ i ];
				pmse[ i ][ offset ]   =  min_mse[ i ];
			}

			for ( m = 0; m < BLK_H; m++ )
			{
				y1   =  y + (m<<1) - ( BLK_H-1 );
				if ( y1<0 || y1>=height )   continue;

				for ( k = 0; k < BLK_W; k++ )
				{
					x1   =  x + (k<<1) - ( BLK_W-1 );
					if ( (x1<0 || x1>=width) || ( x1==x && y1==y ) )   continue;

					offset   =  y1*width + x1;

					for ( i = 0; i < N; i ++ )
					{
						if ( min_mse[i] == MAX_FLOAT ) 
						{
							break;
						}

						mvx[ i ][ offset ]   =  imx[ i ];
						mvy[ i ][ offset ]   =  imy[ i ];

						cx    =  x1 + imx[i];
						cy    =  y1 + imy[i];

						pmse[ i ][ offset ]   =  Cal_SAD_New( cur_fra, x1, y1, pre_fra, cx, cy, width, height );
					}
				}
			}
		}
	}




	// For the pixels in the Odd rows, Even cols
	y_offset    =  WSIZE/2;
	y_offset    =  ( (y_offset%2)==0 ) ? (y_offset+1) : y_offset;
	x_offset    =  WSIZE/2;
	x_offset    =  ( (x_offset%2)==1 ) ? (x_offset+1) : x_offset;

	for ( y_idx = y_offset; y_idx < height; y_idx  += (BLK_H<<1) )
	{
		y        =  y_idx;
		y_up     =  ( (y - (WSIZE-1)/2 )<T ) ? (-y + (WSIZE-1)/2 ) : (-T);
		y_down   =  ( (height-y-WSIZE/2) < T ) ? ( height-y-WSIZE/2 ) : T;

		for ( x_idx = x_offset; x_idx < width; x_idx  += (BLK_W<<1) )
		{
			x         =  x_idx;
			x_left    =  ( ( x- (WSIZE-1)/2 ) <T ) ? ( -x + (WSIZE-1)/2 ) : (-T);
			x_right   =  ( ( width - x - WSIZE/2 ) < T ) ? ( width - x - (WSIZE/2) ) : T;


			for ( i = 0; i < N; i++ )
			{
				min_mse[i]   =  MAX_FLOAT;
				imx[ i ]     =  0;
				imy[ i ]     =  0;
			}

			for ( iy = y_up; iy < y_down; iy++  )
			{
				for ( ix = x_left; ix < x_right; ix ++ )
				{
					cx    =  ix + x;
					cy    =  iy + y;

					if ( !((cx%2==0)&&(cy%2==0)) )   continue;

					tmp   = Cal_SAD_New( cur_fra, x, y, pre_fra, cx, cy, width, height );

					for ( i = 0; i < N; i ++ )
					{
						if ( min_mse[i]>tmp )
						{
							for ( j = N-1; j>i; j-- )
							{
								min_mse[ j ]   =  min_mse[ j-1 ];
								imx[ j ]       =  imx[ j-1 ];
								imy[ j ]       =  imy[ j-1 ];
							}
							min_mse[ i ]       =  tmp;
							imx[ i ]           =  ix;
							imy[ i ]           =  iy;
							break;
						}
					}
				}
			}

			offset   =  y_idx*x_num+x_idx;
			for ( i = 0; i < N; i ++ )
			{
				mvx[ i ][ offset ]    =  imx[ i ];
				mvy[ i ][ offset ]    =  imy[ i ];
				pmse[ i ][ offset ]   =  min_mse[ i ];
			}

			for ( m = 0; m < BLK_H; m++ )
			{
				y1   =  y + (m<<1) - ( BLK_H-1 );
				if ( y1<0 || y1>=height )   continue;

				for ( k = 0; k < BLK_W; k++ )
				{
					x1   =  x + (k<<1) - ( BLK_W-1 );
					if ( (x1<0 || x1>=width) || ( x1==x && y1==y ) )   continue;

					offset   =  y1*width + x1;

					for ( i = 0; i < N; i ++ )
					{
						if ( min_mse[i] == MAX_FLOAT ) 
						{
							break;
						}

						mvx[ i ][ offset ]   =  imx[ i ];
						mvy[ i ][ offset ]   =  imy[ i ];

						cx    =  x1 + imx[i];
						cy    =  y1 + imy[i];

						pmse[ i ][ offset ]   =  Cal_SAD_New( cur_fra, x1, y1, pre_fra, cx, cy, width, height );
					}
				}
			}
		}
	}
}



inline float Cal_SAD_New( unsigned char *cur_fra, int x, int y, unsigned char *ref_fra, int cx, int cy, int width, int height )
{
	register int              row_st_c, row_end_c, row_st_r, row_end_r, col_st_c, col_end_c, col_st_r, col_end_r, i, j, num = WSIZE*WSIZE, flag_c, flag_r;
	register unsigned char    *pcur, *pref;
	register int              tmp, sum = 0, row_c, col_c, row_r, col_r, offset_c, offset_r;
	register float            sad;



	row_st_c      =  y-(WSIZE-1)/2;
	row_end_c     =  row_st_c + (WSIZE-1);
	col_st_c      =  x-(WSIZE-1)/2;
	col_end_c     =  col_st_c + (WSIZE-1);

	if ( (row_st_c>=0 && row_end_c<height) && (col_st_c>=0 && col_end_c<width) )
	{
		flag_c   =  1;
	}
	else
	{
		flag_c   =  0;
	}


	row_st_r      =  cy-(WSIZE-1)/2;
	row_end_r     =  row_st_r + (WSIZE-1);
	col_st_r      =  cx-(WSIZE-1)/2;
	col_end_r     =  col_st_r + (WSIZE-1);

	if ( (row_st_r>=0 && row_end_r<height) && (col_st_r>=0 && col_end_r<width) )
	{
		flag_r   =  1;
	}
	else
	{
		flag_r   =  0;
	}


	if ( flag_c && flag_r )
	{
		pcur    =  &cur_fra[ row_st_c*width+col_st_c ];
		pref    =  &ref_fra[ row_st_r*width+col_st_r ];

		for ( i = 0; i < WSIZE; i ++ )
		{
			for ( j = 0; j < WSIZE; j++ )
			{
				tmp   =  ( pref[ j ]>pcur[ j ] ) ? ( pref[ j ]-pcur[ j ] ) : ( pcur[ j ]-pref[ j ] );
				sum   +=  tmp;
			}
			pcur    +=  width;
			pref    +=  width;
		}
	}
	else 
	{
		for ( i = 0; i < WSIZE; i ++ )
		{
			row_c   = row_st_c + i;
			if ( row_c<0 )                row_c    =  -row_c;
			else if ( row_c>=height )     row_c    =  2*(height-1)-row_c;

			row_r   = row_st_r + i;
			if ( row_r<0 )                row_r    =  -row_r;
			else if ( row_r>=height )     row_r    =  2*(height-1)-row_r;

			for ( j = 0; j < WSIZE; j ++ )
			{
				col_c   = col_st_c + j;
				if ( col_c<0 )                col_c    =  -col_c;
				else if ( col_c>=width )      col_c    =  2*(width-1)-col_c;

				col_r   = col_st_r + j;
				if ( col_r<0 )                col_r    =  -col_r;
				else if ( col_r>=width )      col_r    =  2*(width-1)-col_r;

				offset_c   =  row_c*width+col_c;
				offset_r   =  row_r*width+col_r;

				tmp   =  ( ref_fra[ offset_r ]>cur_fra[ offset_c ] ) ? ( ref_fra[ offset_r ]-cur_fra[ offset_c ] ) : ( cur_fra[ offset_c ]-ref_fra[ offset_r ] );
				sum   +=  tmp;
			}
		}
	}

	sad    =  sum;
	sad   /=  num;
	return sad;
}




inline void Data_fusion( unsigned char *phr, unsigned char pix, unsigned char *obs, float *mse, int n_ref )
{
	register float           h, w, wmax = 0, swei, avg;
	register int             idx;


	h       =  H;
	avg     =  0;
	swei    =  0;
	for ( idx = 0; idx < n_ref; idx ++ )
	{
		if ( mse[idx]>SAD_THRESH )    continue;

		w    =  exp( -mse[idx]/h );
		if ( w>wmax )
		{
			wmax    =  w;
		}
		swei   +=  w;
		avg    +=  w*obs[idx];
	}

	if ( swei==0 )
	{
		return;
	}


	avg     +=  wmax*pix;
	swei    +=  wmax;

	avg     /=  swei;

	if ( avg<0 )
	{
		avg   = 0;
	}
	else if ( avg>255 )
	{
		avg   =  255;
	}
	else
		avg   +=  0.5;

	*phr   =  (unsigned char) avg;
}



inline void Data_fusion_float( float *phr, float pix, float *obs, float *mse, int n_ref )
{
	register float           h, w, wmax = 0, swei, avg;
	register int             idx;


	h       =  H;
	avg     =  0;
	swei    =  0;
	for ( idx = 0; idx < n_ref; idx ++ )
	{
		if ( mse[idx]>SAD_THRESH )    continue;

		w    =  exp( -mse[idx]/h );
		if ( w>wmax )
		{
			wmax    =  w;
		}
		swei   +=  w;
		avg    +=  w*obs[idx];
	}

	if ( swei==0 )
	{
		return;
	}


	avg     +=  wmax*pix;
	swei    +=  wmax;

	avg     /=  swei;

	*phr   =  avg;
}



void Downsampling( unsigned char *lr_im, unsigned char *hr_im, int scale, int width, int height, float *lp_filter )
{
	int          row, col, row1, col1, lwidth, lheight, m, k, cnt, lrow, lcol;
	float        sum, tmp;



	lwidth    =  width  / scale;
	lheight   =  height / scale;

	for ( row = 0, lrow = 0; row < height; row += scale, lrow++ )
	{
		for ( col = 0, lcol = 0; col < width; col += scale, lcol++ )
		{
			sum    =  0;
			cnt    =  0;
			for ( m = 0; m < KER_HEIGHT; m ++ )
			{
				row1    =  row - (KER_HEIGHT/2) + m;

				if ( row1<0 )                  row1   =  -row1;
				else if ( row1>=height )       row1   =  2*(height-1)-row1;

				for ( k = 0; k < KER_WIDTH; k ++ )
				{
					col1   =  col - (KER_WIDTH/2) + k;

					if ( col1<0 )              col1   =  -col1;
					else if ( col1>=width )    col1   =  2*(width-1)-col1;

					sum   +=  hr_im[ row1*width+col1 ] * lp_filter[ cnt++ ];
				}
			}
			tmp    =  ( sum<0 ) ? 0 : ( (sum>255) ? 255 : sum );

			lr_im[ lrow*lwidth+lcol ]   =  (unsigned char) tmp;
		}
	}
}



void Bicubic( unsigned char *pLR, unsigned char *pHR, int scale, int lwidth, int lheight )
{
	int             row, col, idx, row1, col1, width, height;
	float           pixel;
	float           cubic[ 4 ]    =  { -1.0/16, 9.0/16, 9.0/16, -1.0/16 };


	width     =  lwidth * scale;
	height    =  lheight * scale;

	for(row=0; row<lheight; row++ )
	{
		for( col=0; col<lwidth; col++ )
		{
			pHR[ (row*scale)*width+(col*scale) ]   =  pLR[ row*lwidth+col ];
		}
	}


	// for the case that scale = 2;

	for( row=1; row<height; row+=2 )
	{
		for( col=0; col<width; col+=2 )
		{
			pixel   = 0;

			for( idx =0; idx < 4; idx++ )
			{
				col1    =  col;
				row1    =  row - 3 + ( idx<<1 );

				if( row1<0 )               row1    =  -row1;
				else if( row1>=height )    row1    =  2*(height-1)-row1;

				pixel += pHR[ row1*width+col1 ]*cubic[ idx ];
			}

			if ( pixel<0 )            pixel    =  0;
			else if ( pixel>255 )     pixel    =  255;

			pHR[ row*width+col ]   = (unsigned char)( pixel+0.5 );
		}
	}

	for( row=0; row<height; row++ )
	{
		for( col=1; col<width; col+=2 )
		{
			pixel = 0;
			for( idx=0; idx < 4; idx++ )
			{
				row1   =  row;
				col1   =  col - 3 + (idx<<1);

				if( col1<0 )                col1  = -col1;
				else if( col1>=width )      col1  = 2*(width-1)-col1;

				pixel += pHR[ row1*width+col1 ] * cubic[ idx ];
			}
			if ( pixel<0 )           pixel   =  0;
			else if ( pixel>255 )    pixel   =  255;

			pHR[ row*width+col ]  = (unsigned char)( pixel+0.5 );
		}
	}
}


void Bicubic_float( float *im, int width, int height )
{
	int             row, col, idx, row1, col1;
	float           pixel;
	float           cubic[ 4 ]    =  { -1.0/16, 9.0/16, 9.0/16, -1.0/16 };


	// for the case that scale = 2;

	for( row = 1; row < height; row += 2 )
	{
		for( col = 0; col < width; col += 2 )
		{
			pixel   = 0;

			for( idx =0; idx < 4; idx++ )
			{
				col1    =  col;
				row1    =  row - 3 + ( idx<<1 );

				if( row1<0 )               row1    =  -row1;
				else if( row1>=height )    row1    =  2*(height-1)-row1;

				pixel    +=  im[ row1*width+col1 ]*cubic[ idx ];
			}
			im[ row*width+col ]   = pixel;
		}
	}

	for( row = 0; row < height; row ++ )
	{
		for( col = 1; col < width; col += 2 )
		{
			pixel   = 0;
			for( idx = 0; idx < 4; idx ++ )
			{
				row1    =  row;
				col1    =  col - 3 + (idx<<1);

				if( col1 < 0 )                col1  = -col1;
				else if( col1 >= width )      col1  = 2*(width-1)-col1;

				pixel   += im[ row1*width+col1 ] * cubic[ idx ];
			}

			im[ row*width+col ]   =  pixel;
		}
	}
}



int Get_image_size( char *input_frame, int *width, int *height )
{
	char            fname[ 100 ];
	FILE            *fp;
	int             maxval, comp;


	sprintf( fname, input_frame, 1 );

	if( !(fp=fopen( fname, "rb" )) )
	{
		printf("Cannot open file: %s.\n", fname );
		return 1;
	}
	if( read_header(fp, width, height, &maxval, &comp) )
	{
		printf( "PGM file %s header error.\n", fname );
		return 1;
	}

	return 0;
}



int  Read_image( char *fname, unsigned char *pdat )
{
	FILE                  *fp;
	int                   width, height, maxval, comp;


	if( !(fp=fopen( fname, "rb" )) )
	{
		printf("Cannot open file: %s.\n", fname );
		return 1;
	}
	if( read_header(fp, &width, &height, &maxval, &comp) )
	{
		printf( "PGM file %s header error.\n", fname );
		return 1;
	}
	if( (maxval != 255) || (comp!=1) )
	{
		printf("Format error.\n");
		return 1;
	}

	if ( fread( pdat, sizeof(unsigned char), width*height, fp) != width*height )
	{
		printf( "\nRead file error.\n" );
		return 1;
	}
	fclose(fp);

	return 0;
}



double Cal_psnr( unsigned char *pOrig, unsigned char *pImg, int width, int height )
{
	double         tmp, sum = 0, mean, psnr;
	int            row, col, offset, cnt = 0;
	int            BOU_WIDTH  =  2;


	for ( row = BOU_WIDTH; row < (height-BOU_WIDTH); row++ )
	{
		for ( col = BOU_WIDTH; col < (width-BOU_WIDTH); col++ )
		{
			offset   =  row*width+col;
			tmp      =  pOrig[offset]-pImg[offset];
			sum     +=  tmp*tmp;
			cnt ++;
		}
	}
	mean   =  sum / cnt;
	psnr   =  10*log10(255*255/mean);

	return psnr;
}


void Write2PGM( unsigned char *pImg, int width, int height, char *fname )
{
	FILE *fp;

	fp = fopen( fname, "wb");
	if(fp){
		fprintf(fp, "P5\n %d %d\n%d\n", width, height, 255);
		fwrite(pImg, sizeof(unsigned char), width*height, fp);
		fclose(fp);
	}
}
