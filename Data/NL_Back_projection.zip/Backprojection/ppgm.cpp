#define _CRT_SECURE_NO_DEPRECATE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Routines that read the PGM/PPM header 
#define HEADER_MAXLINE 256
#define DPX_HEADER_SIZE 8192
// Used to read in header lines of PGM/PPM files 
int nextline(char *line, FILE *fp)
{
	char *p;
	do {
		p = fgets(line, HEADER_MAXLINE, fp);
	} while ( p != NULL && *p == '#' );
	if( p==NULL )
		return -1;
	return 0;
}

int read_header(FILE *fin, int *widthp, int *heightp, int *maxvalp, int *comp)
{
	char line[HEADER_MAXLINE];
	int  cols,rows,maxval;
	if(nextline(line, fin)!=0)	return -10;
	if(strncmp(line,"P5",2)==0)	
		*comp=1;
	else if (strncmp(line,"P6",2)==0) 
		*comp=3;
	else if (strncmp(line,"P7",2)==0) 
		*comp=4;
	else 
		return -1;
	if(strlen(line)>3)
	{
		if(sscanf(line+2,"%d %d %d",&cols,&rows,&maxval )!=3 )
			return -1;
	}
	else
	{
		if(nextline(line, fin)!=0)	return -10;
		if(sscanf(line,"%d %d",&cols,&rows)!=2 )
			return -1;
		if(nextline(line, fin)!=0)	return -10;
		if(sscanf(line,"%d",&maxval)!=1)
			return -1;
	}
	*widthp = cols;
	*heightp = rows;
	*maxvalp = maxval;
	return 0;
}