import torch
import math
import torch.nn.functional as F
from torch.nn.modules import Module
from torch.nn.parameter import Parameter
from torch.nn.modules.utils import _pair as pair
from torch.autograd import Variable
from torch.nn import init


class relu_theta(Module):
    def __init__(self, in_channels, inplace=True, **kwargs):
        """
        :param in_channels: Number of input channels
        :param out_channels: Number of output channels
        :param lamda: the value of lambda
        """
        super(relu_theta, self).__init__()
        self.in_channels = in_channels
        self.floatTensor = torch.FloatTensor if not torch.cuda.is_available() else torch.cuda.FloatTensor
        self.theta       = Parameter(torch.Tensor(in_channels))
        self.lamda = Parameter(torch.ones(in_channels))
        self.input_shape = None
        self.reset_parameters()
        # print(self)

    def reset_parameters(self):
        torch.nn.init.normal_(self.theta,mean = 0.5,std = 0.01)


    def forward(self, input_):
        if self.input_shape is None:
            self.input_shape = input_.size()
        output  =  F.relu(input_,inplace=True)
        theta = self.theta.view(1, self.in_channels, 1, 1)
        output   =   output.mul(theta)
        return output