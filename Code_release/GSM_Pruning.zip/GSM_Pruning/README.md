# GSM-Pruning
Accelerating Convolutional Neural Network via Structured Gaussian Scale Mixture Models: a Joint Grouping and Pruning Approach.

Please cite this paper [1] if you use this code. 

For further information, please contact: wsdong@mail.xidian.edu.cn

# Acknowledgements
Some parts of our code is based on Network Slimming [2]. We thank the authors for sharing their codes. (https://github.com/foolwood/pytorch-slimming)


## Reference
[1] Tao Huang, Weisheng Dong, Jinshan Liu, Fangfang Wu, Guangming Shi, and Xin Li, “Accelerating Convolutional Neural Network via Structured Gaussian Scale Mixture Models: a Joint Grouping and Pruning Approach”, IEEE Journal of Selected Topics in Signal Processing, 2020. 

[2] Zhuang Liu, Jianguo Li, Zhiqiang Shen, Gao Huang, Shoumeng Yan and Changshui Zhang. "Learning Efficient Convolutional Networks Through Network Slimming", The IEEE International Conference on Computer Vision (ICCV), 2017.