import  torch
import  torch.nn as nn
from    model.operations_nobn import *
from    model.utils import drop_path
from model import common
from    model.genotypes import COMPACT_PRIMITIVES as PRIMITIVES
from    model.genotypes import Genotype
from model import genotypes
def make_model(args, parent=False):
    return Network(args)
class Cell(nn.Module):

    def __init__(self, genotype, cp, c,lens,nodes):
        """

        :param genotype:
        :param C_prev_prev:
        :param C_prev:
        :param C:
        :param reduction:
        :param reduction_prev:
        """
        super(Cell, self).__init__()
        self.len = lens
        self.nodes = nodes
        self.c = c
        print( cp, c)


        # preprocess1 deal with output from prev cell
        self.preprocess1 = nn.Sequential(
            *[ReLUConv(cp, c, 3, 1, 1, affine=False), ReLUConv(c, c, 3, 1, 1, affine=False)])
        self.layers_fuser = nn.ModuleList()
        self.layers_normal = nn.ModuleList()
        self.layers_down = nn.ModuleList()
        self.layers_up = nn.ModuleList()
        self.layers_align = nn.ModuleList()
        op_names_normal, indices_normal = zip(*genotype.normal)
        ch_normal = genotype.normal_concat
        op_names_up, indices_up = zip(*genotype.up)
        ch_up = genotype.up_concat
        op_names_down, indices_down = zip(*genotype.down)
        ch_down = genotype.down_concat
        # ch_normal = [ch_normal[i]*2 for i in range(len(ch_normal))]
        # ch_up = [ch_normal[i]*2 for i in range(len(ch_up))]
        # ch_down = [ch_normal[i]*2 for i in range(len(ch_down))]

        self.C_F = []
        for i in range(self.len):
            self.C_F.append(ch_normal[self.nodes*(self.len-i)-1]+ch_up[i])

        self.layers_normal,self.layers_up,self.layers_down = self._compile(op_names_normal,op_names_up,op_names_down, indices_normal,ch_normal,ch_up,ch_down)

        for i in range(self.len):
            self.layers_fuser.append(nn.Conv2d(in_channels=self.C_F[i], out_channels=int(self.C_F[i]/2), kernel_size=3,padding=1, bias=False))

        # print(len(self.layers_normal))
        # print(len(self.layers_up))
        # print(len(self.layers_down))
    def cat(self,x,map):
        diffY = torch.tensor([map.size()[2]-x.size()[2]])
        diffX = torch.tensor([map.size()[3]-x.size()[3]])

        x = F.pad(x,[diffX//2,diffX-diffX//2,diffY//2,diffY-diffY//2])
        return torch.cat([x,map],dim=1)


    def _compile(self, op_names_normal,op_names_up,op_names_down, indices, ch_normal,ch_up,ch_down):
        """

        :param C:
        :param op_names:
        :param indices:
        :param concat:
        :param reduction:
        :return:
        """

        ops_normal = nn.ModuleList()
        ops_up = nn.ModuleList()
        ops_down = nn.ModuleList()
        stride = 1
        C_out = self.c
        # print(C_out)
        for j in range(2*self.len+1):
            # print(j)
            if j>self.len:
                k = j-self.len-1

                C_in = C_out
                C_out = ch_up[k]
                op = OPS[op_names_up[k]](C_in, C_out, stride, True)
                ops_up += [op]
                C_out = int(self.C_F[k]/2)

            for i in range(self.nodes): # 4
                # [40, 16, 32, 32]
                C_in = C_out
                if op_names_normal[j*self.nodes+i] == 'skip':
                    C_out = C_in
                else:
                    C_out = ch_normal[j*self.nodes+i]

                op = OPS[op_names_normal[j*self.nodes+i]](C_in, C_out, stride, True)
                ops_normal += [op]
            if j<self.len:
                C_in = C_out
                C_out = ch_down[j]
                op = OPS[op_names_down[j]](C_in, C_out, stride, True)
                ops_down += [op]

        self._indices = indices
        return ops_normal,ops_up, ops_down
    def forward(self, s1):
        """

        :param s0:
        :param s1:
        :param drop_prob:
        :return:
        """
        s1 = self.preprocess1(s1)
        # print(s1.shape)
        encode_list = []

        for j in range(2*self.len+1):
            # print(j)
            if j>self.len:
                k = j-self.len-1
                s1 = self.layers_up[k](s1)
                map = encode_list[self.len - 1 - k]
                s1_catted = self.cat(s1, map)
                s1 = self.layers_fuser[k](s1_catted)

            for i in range(self.nodes): # 4
                # [40, 16, 32, 32]
                # print(j,i)
                s1 =self.layers_normal[j*self.nodes+i](s1)
                # print(s1.shape)
            if j<self.len:
                encode_list.append(s1)
                s1 = self.layers_down[j](s1)

        return s1




class Recon(nn.Module):
    def __init__(self,):
        super(Recon, self).__init__()


        self.delta = nn.Parameter(torch.tensor(0.1,requires_grad=True))

        self.elta = nn.Parameter(torch.tensor(0.9,requires_grad=True))

    def forward(self,y,v,x):

        return x-self.delta*((x-y)+self.elta*(x-v))


class Network(nn.Module):

    """
    stack number:layer of cells and then flatten to fed a linear layer
    """
    def __init__(self,args, conv=common.default_conv):
        """

        :param c: 16
        :param layers: number of cells of current network
        :param criterion:
        :param nodes: nodes num inside cell
        :param multiplier: output channel of cell = multiplier * ch
        :param stem_multiplier: output channel of stem net = stem_multiplier * ch
        """
        super(Network, self).__init__()

        self.c = args.init_channels
        self.layers = args.layers
        self.criterion = nn.MSELoss().cuda()
        self.nodes = args.nodes
        self.args = args
        genotype = eval("genotypes.%s" % args.genotype)
        # self.multiplier = args.multiplier


        # stem_multiplier is for stem network,
        # and multiplier is for general cell
        c_curr = args.n_colors # 3*16



        # c_curr means a factor of the output channels of current cell
        # output channels = multiplier * c_curr
        cp, c_curr = c_curr, self.c # 48, 48, 16
        self.cells = nn.ModuleList()

        for i in range(self.layers):

            # # for layer in the middle [1/3, 2/3], reduce via stride=2
            # if i in [layers // 3, 2 * layers // 3]:
            #     c_curr *= 2
            #     reduction = True
            # else:
            #     reduction = False

            # [cp, h, h] => [multiplier*c_curr, h/h//2, h/h//2]
            # the output channels = multiplier * c_curr
            cell = Cell(genotype, cp, c_curr,args.len,args.nodes)
            # update reduction_prev


            self.cells += [cell]

        self.recon = nn.ModuleList([Recon() for _ in range(self.layers)])
        self.transform = nn.ModuleList(
            [ReLUConv(genotype.normal_concat[-1], args.n_colors, 1, 1, 0, affine=False) for _ in range(self.layers)])

        # k is the total number of edges inside single cell, 14
        k = sum(1 for i in range(self.nodes) for j in range(2 + i))
        num_ops = len(PRIMITIVES) # 8

        # TODO
        # this kind of implementation will add alpha into self.parameters()
        # it has num k of alpha parameters, and each alpha shape: [num_ops]
        # it requires grad and can be converted to cpu/gpu automatically
        self.arch_alpha_normal = nn.Parameter(torch.randn(k, num_ops))
        # self.arch_alpha_reduce = nn.Parameter(torch.randn(k, num_ops))
        with torch.no_grad():
            # initialize to smaller value
            self.arch_alpha_normal.mul_(1e-3)
            # self.arch_alpha_reduce.mul_(1e-3)
        self._arch_parameters = [
            self.arch_alpha_normal,
            # self.arch_alpha_reduce,
        ]




    def new(self):
        """
        create a new model and initialize it with current alpha parameters.
        However, its weights are left untouched.
        :return:
        """
        model_new = Network(self.args).cuda()
        for x, y in zip(model_new.arch_parameters(), self.arch_parameters()):
            x.data.copy_(y.data)
        return model_new
    def forward(self, x):
        y = x.cuda()
        x = y
        x1 = x # [b, 3, 32, 32] => [b, 48, 32, 32]
        # print('stem:', s0.shape)

        for i, cell in enumerate(self.cells):
            # weights are shared across all reduction cell or normal cell
            # according to current cell's type, it choose which architecture parameters
            # to use
            # if cell.reduction: # if current cell is reduction cell
                # weights = F.softmax(self.arch_alpha_reduce, dim=-1)
            # else:
            # weights = F.softmax(self.arch_alpha_normal, dim=-1) # [14, 8]
            # execute cell() firstly and then assign s0=s1, s1=result
            v = cell(x1) # [40, 64, 32, 32]
            v1 = self.transform[i](v)+x1
            # print('cell:',i, s1.shape, cell.reduction, cell.reduction_prev)
            # print('\n')
            x1 = self.recon[i](y,v1,x1)

        # s1 is the last cell's output
        # out = self.global_pooling(s1)
        # print('pool', out.shape)
        # logits = self.classifier(out.view(out.size(0), -1))
        # logits = self.tail(s1)
        return x1

  

    def loss(self, x, target):
        """

        :param x:
        :param target:
        :return:
        """
        logits = self(x)
        return self.criterion(logits, target)



    def arch_parameters(self):
        return self._arch_parameters
    def model_parameters(self):
        for k, v in self.named_parameters():
            if 'arch_p' not in k:
                yield v



    def genotype(self):
        """

        :return:
        """
        def _parse(weights):
            """

            :param weights: [14, 8]
            :return:
            """
            gene = []
            n = 2
            start = 0
            for i in range(self.nodes): # for each node
                end = start + n
                W = weights[start:end].copy() # [2, 8], [3, 8], ...
                edges = sorted(range(i + 2), # i+2 is the number of connection for node i
                            key=lambda x: -max(W[x][k] # by descending order
                                               for k in range(len(W[x])) # get strongest ops
                                               if k != PRIMITIVES.index('none'))
                               )[:2] # only has two inputs
                for j in edges: # for every input nodes j of current node i
                    k_best = None
                    for k in range(len(W[j])): # get strongest ops for current input j->i
                        if k != PRIMITIVES.index('none'):
                            if k_best is None or W[j][k] > W[j][k_best]:
                                k_best = k
                    gene.append((PRIMITIVES[k_best], j)) # save ops and input node
                start = end
                n += 1
            return gene

        gene_normal = _parse(F.softmax(self.arch_alpha_normal, dim=-1).data.cpu().numpy())
        # gene_reduce = _parse(F.softmax(self.arch_alpha_reduce, dim=-1).data.cpu().numpy())

        concat = range(2 + self.nodes - 1, self.nodes + 2)
        genotype = Genotype(
            normal=gene_normal, normal_concat=concat,
            # upsampling=gene_reduce, upsampling_concat=concat


        )

        return genotype
    def load_state_dict(self, state_dict, strict=False):
        own_state = self.state_dict()
        for name, param in state_dict.items():
            if name in own_state:
                if isinstance(param, nn.Parameter):
                    param = param.data
                try:
                    own_state[name].copy_(param)
                except Exception:
                    if name.find('tail') >= 0:
                        print('Replace pre-trained upsampler to new one...')
                    else:
                        raise RuntimeError('While copying the parameter named {}, '
                                           'whose dimensions in the model are {} and '
                                           'whose dimensions in the checkpoint are {}.'
                                           .format(name, own_state[name].size(), param.size()))
            elif strict:
                if name.find('tail') == -1:
                    raise KeyError('unexpected key "{}" in state_dict'
                                   .format(name))

        if strict:
            missing = set(own_state.keys()) - set(state_dict.keys())
            if len(missing) > 0:
                raise KeyError('missing keys in state_dict: "{}"'.format(missing))








