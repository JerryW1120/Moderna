import  torch
from    torch import nn
import  torch.nn.functional as F
from    model.operations_nobn import OPS, FactorizedReduce, ReLUConv
from    model.genotypes import *
from    model.genotypes import Genotype
from model import common
from model.common import default_conv as conv
from model.utils import arch_to_genotype
import numpy as np
def make_model(args, parent=False):
    return Network(args)

class MixedLayer(nn.Module):
    """
    a mixtures output of 8 type of units.

    we use weights to aggregate these outputs while training.
    and softmax to select the strongest edges while inference.
    """
    def __init__(self, c, stride,type):

        super(MixedLayer, self).__init__()

        self.layers = nn.ModuleList()
        if type == 'normal':
            cell_type = COMPACT_PRIMITIVES
        elif type == 'down':
            cell_type =COMPACT_PRIMITIVES_DOWNSAMPLING
        elif type == 'up':
            cell_type = COMPACT_PRIMITIVES_UPSAMPLING

        for primitive in cell_type:
            # create corresponding layer

            layer = OPS[primitive](c, c, stride, False)
            # print(layer)
            # append batchnorm after pool layer
            if 'pool' in primitive:
                # disable affine w/b for batchnorm
                layer = nn.Sequential(layer, nn.BatchNorm2d(c, affine=False))

            self.layers.append(layer)

    def forward(self, x, weights,ch_alpha):
        """

        :param x: data
        :param weights: alpha,[op_num:8], the output = sum of alpha * op(x)
        :return:
        """
        res = []


        for i in range(len(self.layers)):
            # print(ch_alpha.shape)
            # print(weights.shape)
            # # a =ch_alpha[i:i+1,:,:]
            # # print(a.shape)
            # b = weights[i]
            res.append(weights[i]*(ch_alpha[i:i+1,:,:]*self.layers[i](x)))

        # res = [w * (layer(x)) for w, layer in zip(weights, self.layers)]
        # print('*'*25)
        # print(ch_alpha[-1])
        # element-wise add by torch.add
        res = sum(res)
        return res



class Cell(nn.Module):

    def __init__(self, steps, multiplier, cp, c,len):

        super(Cell, self).__init__()

        # indicating current cell is reduction or not

        # preprocess0 deal with output from prev_prev cell


        self.preprocess1 =nn.Sequential(*[ReLUConv(cp, c, 3, 1, 1, affine=False),ReLUConv(c, c, 3, 1, 1, affine=False)])

        # steps inside a cell
        self.steps = steps # 4
        self.multiplier = multiplier # 4
        self.len = len
        self.layers_normal = nn.ModuleList()
        self.layers_down = nn.ModuleList()
        self.layers_up = nn.ModuleList()
        self.layers_fuser = nn.ModuleList()
        for _ in range(2*(self.len)+1):
            for i in range(self.steps):
                # for each i inside cell, it connects with all previous output
                # plus previous two cells' output

                    # for reduction cell, it will reduce the heading 2 inputs only
                stride = 1
                layer = MixedLayer(c, stride,type='normal')
                self.layers_normal.append(layer)
        for _ in range(self.len):
            stride = 2
            self.layers_up.append(MixedLayer(c,stride,type='up'))
        for _ in range(self.len):
            stride = 0.5
            self.layers_down.append(MixedLayer(c,stride,type='down'))
        for _ in range(self.len):
            self.layers_fuser.append(nn.Conv2d(in_channels=2*c, out_channels=c, kernel_size=3,padding=1, bias=False))

    def cat(self,x,map):
        diffY = torch.tensor([map.size()[2]-x.size()[2]])
        diffX = torch.tensor([map.size()[3]-x.size()[3]])

        x = F.pad(x,[diffX//2,diffX-diffX//2,diffY//2,diffY-diffY//2])
        return torch.cat([x,map],dim=1)


    def forward(self,  s1, weights_normal,weight_up,weight_down,weight_ch):

        s1 = self.preprocess1(s1) # [40, 48, 32, 32], [40, 16, 32, 32]
        encode_list = []
        weight_ch_normal = weight_ch[0]
        weight_ch_up = weight_ch[1]
        weight_ch_down = weight_ch[2]

    
        # encoding
        for j in range(2*self.len+1):
            if j>self.len:
                k = j-self.len-1
                s1 = self.layers_up[k](s1, weight_up[k],weight_ch_up[k])
                map = encode_list[self.len - 1 - k]
                s1_catted = self.cat(s1, map)
                s1 = self.layers_fuser[k](s1_catted)

            for i in range(self.steps): # 4
                # [40, 16, 32, 32]
                s1 =self.layers_normal[j*self.steps+i](s1, weights_normal[j*self.steps+i],weight_ch_normal[j*self.steps+i])
                # print(s1.shape)
            if j<self.len:
                encode_list.append(s1)
                s1 = self.layers_down[j](s1, weight_down[j],weight_ch_down[j])



        return s1 # 6 of [40, 16, 32, 32]


class Recon(nn.Module):
    def __init__(self,):
        super(Recon, self).__init__()


        self.delta = nn.Parameter(torch.tensor(0.1,requires_grad=True))

        self.elta = nn.Parameter(torch.tensor(0.9,requires_grad=True))

    def forward(self,y,v,x):
        # print(self.delta)
        # print(self.elta)

        return x-self.delta*((x-y)+self.elta*(x-v))


class Network(nn.Module):

    """
    stack number:layer of cells and then flatten to fed a linear layer
    """
    def __init__(self,args, multiplier=1):
        """

        :param c: 16
        :param layers: number of cells of current network
        :param criterion:
        :param steps: nodes num inside cell
        :param multiplier: output channel of cell = multiplier * ch
        :param stem_multiplier: output channel of stem net = stem_multiplier * ch
        """
        super(Network, self).__init__()

        self.c = args.init_channels
        self.layers = args.layers
        self.criterion = nn.MSELoss().cuda()
        self.steps = args.nodes
        self.args = args
        self.multiplier = 1
        self.len = args.len

        # stem_multiplier is for stem network,
        # and multiplier is for general cell
        c_curr = args.n_colors # 3*16


        cp, c_curr =  c_curr, self.c # 48, 48, 16
        self.cells = nn.ModuleList()

        for i in range(self.layers):

            cell = Cell(self.steps, self.multiplier,  cp, c_curr,self.len)
            self.cells += [cell]

        self.recon = nn.ModuleList([Recon() for _ in range(self.layers)])
        self.transform = nn.ModuleList([ReLUConv(self.multiplier*self.c, args.n_colors, 1, 1, 0, affine=False) for _ in range(self.layers)])

        # k is the total number of edges inside single cell, 14
        k = self.steps*(2*self.len+1)
         # 8

        # TODO
        # this kind of implementation will add alpha into self.parameters()
        # it has num k of alpha parameters, and each alpha shape: [num_ops]
        # it requires grad and can be converted to cpu/gpu automatically
        self.arch_alpha_normal = nn.Parameter(torch.randn(k, len(COMPACT_PRIMITIVES)))
        self.arch_alpha_up = nn.Parameter(torch.randn(self.len, len(COMPACT_PRIMITIVES_UPSAMPLING)))
        self.arch_alpha_down = nn.Parameter(torch.randn(self.len, len(COMPACT_PRIMITIVES_DOWNSAMPLING)))
        self.alpha_ch_normal =nn.ParameterList([nn.Parameter(torch.ones(len(COMPACT_PRIMITIVES), self.c, 1, 1).cuda()) for _ in range(k)])
        self.alpha_ch_up = nn.ParameterList([nn.Parameter(torch.ones(len(COMPACT_PRIMITIVES_UPSAMPLING), self.c, 1, 1).cuda()) for _ in range(self.len)])
        self.alpha_ch_down = nn.ParameterList([nn.Parameter(torch.ones(len(COMPACT_PRIMITIVES_DOWNSAMPLING), self.c, 1, 1).cuda()) for _ in range(self.len)])
        # self.alpha_ch.append([[(torch.randn(1, self.c, 1, 1)).cuda() for _ in range(len(COMPACT_PRIMITIVES_UPSAMPLING))] for _ in range(self.len)])
        # self.alpha_ch.append([[(torch.randn(1, self.c, 1, 1)).cuda() for _ in range(len(COMPACT_PRIMITIVES_DOWNSAMPLING))] for _ in range(self.len)])
        self.alpha_ch = [self.alpha_ch_normal,self.alpha_ch_up,self.alpha_ch_down]
        # self.arch_alpha_reduce = nn.Parameter(torch.randn(k, num_ops))
        with torch.no_grad():
            # initialize to smaller value
            self.arch_alpha_normal.mul_(1e-3)
            self.arch_alpha_up.mul_(1e-3)
            self.arch_alpha_down.mul_(1e-3)
            for i in range(len(self.alpha_ch_normal)):
                self.alpha_ch_normal[i].mul_(1)
            for i in range(len(self.alpha_ch_up)):
                self.alpha_ch_up[i].mul_(1)
                self.alpha_ch_down[i].mul_(1)
            # self.arch_alpha_reduce.mul_(1e-3)
        self._arch_parameters = nn.ParameterList([
            self.arch_alpha_normal,
            self.arch_alpha_up,
            self.arch_alpha_down,
            # self.arch_alpha_reduce,
          ])
        self._arch_parameters.extend(self.alpha_ch_normal)
        self._arch_parameters.extend(self.alpha_ch_up)
        self._arch_parameters.extend(self.alpha_ch_down)
        # increase result
        # modules_tail = [
        #     conv(self.layers*args.n_colors, args.n_colors, 3),nn.ReLU(),
        #     # common.Upsampler(conv, 2, self.c, act=False),
        #     conv(args.n_colors, args.n_colors, 3)]
        #
        # # self.fea = conv(args.n_colors, self.c, 3)
        # self.tail = nn.Sequential(*modules_tail)
    def new(self):
        """
        create a new model and initialize it with current alpha parameters.
        However, its weights are left untouched.
        :return:
        """
        model_new = Network(self.args).cuda()
        for x, y in zip(model_new.arch_parameters(), self.arch_parameters()):
            x.data.copy_(y.data)
        return model_new

    def forward(self, x):
        # print(self.genotype())
        y = x.cuda()
        x = y
        x1 = x # [b, 3, 32, 32] => [b, 48, 32, 32]
        # print('stem:', s0.shape)
        weights_normal = F.softmax(self.arch_alpha_normal, dim=-1)  # [14, 8]
        weights_up = F.softmax(self.arch_alpha_up, dim=-1)  # [14, 8]
        weights_down = F.softmax(self.arch_alpha_down, dim=-1)  # [14, 8]
        for i, cell in enumerate(self.cells):

            v = cell(x1, weights_normal,weights_up,weights_down,self.alpha_ch) # [40, 64, 32, 32]
            v1 = self.transform[i](v)
            # print('cell:',i, s1.shape, cell.reduction, cell.reduction_prev)
            # print('\n')
            x1 = self.recon[i](y,v1,x1)

        # s1 is the last cell's output
        # out = self.global_pooling(s1)
        # print('pool', out.shape)
        # logits = self.classifier(out.view(out.size(0), -1))
        # logits = self.tail(s1)
        return x1

    def loss(self, x, target):
        """

        :param x:
        :param target:
        :return:
        """
        logits = self(x)
        return self.criterion(logits, target)



    def arch_parameters(self):
        return self._arch_parameters
    def model_parameters(self):
        for k, v in self.named_parameters():
            if 'arch' not in k:
                yield v
    def alpha_parameters(self):
        for k, v in self.named_parameters():
            if 'alpha' in k:
                yield v

    def save_arch_to_pdf(self, suffix):
        genotype = arch_to_genotype(self.cur_normal_arch,  self._steps, "COMPACT")
        return genotype

    def genotype(self):
        """

        :return:
        """


        def engery(alpha, per=0.9, stride=8):
            # alpha_2 = pow(alpha.squeeze(0).squeeze(-1).squeeze(-1), 2)
            alpha_2 = abs(alpha.squeeze(0).squeeze(-1).squeeze(-1))
            alpha = sorted(alpha_2, reverse=True)
            gate = per * np.sum(alpha)
            temp = 0
            for i in range(int(len(alpha) / stride)):
                temp += np.sum(alpha[i * stride:(i + 1) * stride])
                if temp > gate:
                    return (i + 1) * stride
            return len(alpha)


        def _parse(weights,ch_weights,type):
            """

            :param weights: [14, 8]
            :return:
            """
            gene = []
            ch_index = []
            n = 1
            start = 0
            if type == 'normal':
                cell_type = COMPACT_PRIMITIVES
                num = self.steps*(2*self.len+1)
            elif type == 'down':
                cell_type = COMPACT_PRIMITIVES_DOWNSAMPLING
                num = self.len
            elif type == 'up':
                cell_type = COMPACT_PRIMITIVES_UPSAMPLING
                num = self.len
            for i in range(num): # for each node
                # print(i)
                end = start + n
                W = weights[start:end].copy() # [2, 8], [3, 8], ...
                edges = sorted(range(0,1), # i+2 is the number of connection for node i
                            key=lambda x: -max(W[x][k] # by descending order
                                               for k in range(len(W[x])) # get strongest ops
                                               )
                               )[:1] # only has two inputs
                for j in edges: # for every input nodes j of current node i
                    k_best = None
                    for k in range(len(W[j])): # get strongest ops for current input j->i

                        if k_best is None or W[j][k] > W[j][k_best]:
                            k_best = k
                    gene.append((cell_type[k_best], i)) # save ops and input node
                    ch_index.append(engery(ch_weights[i][k_best:k_best+1,:,:,:].data.cpu().numpy(),per=0.9))
                start = end
            return gene,ch_index

        gene_normal,ch_normal = _parse(F.softmax(self.arch_alpha_normal, dim=-1).data.cpu().numpy(),self.alpha_ch_normal,type='normal')
        gene_up, up_normal = _parse(F.softmax(self.arch_alpha_up, dim=-1).data.cpu().numpy(),self.alpha_ch_up,type='up')
        gene_down,down_normal = _parse(F.softmax(self.arch_alpha_down, dim=-1).data.cpu().numpy(),self.alpha_ch_down,type='down')
        # gene_reduce = _parse(F.softmax(self.arch_alpha_reduce, dim=-1).data.cpu().numpy())


        genotype = Genotype(
            normal=gene_normal, normal_concat=ch_normal,
            up=gene_up, up_concat=up_normal,
            down=gene_down, down_concat=down_normal,
            # upsampling=gene_reduce, upsampling_concat=concat


        )

        return genotype
    def load_state_dict(self, state_dict, strict=False):
        own_state = self.state_dict()
        for name, param in state_dict.items():
            if name in own_state:
                if isinstance(param, nn.Parameter):
                    param = param.data
                try:
                    own_state[name].copy_(param)
                except Exception:
                    if name.find('tail') >= 0:
                        print('Replace pre-trained upsampler to new one...')
                    else:
                        raise RuntimeError('While copying the parameter named {}, '
                                           'whose dimensions in the model are {} and '
                                           'whose dimensions in the checkpoint are {}.'
                                           .format(name, own_state[name].size(), param.size()))
            elif strict:
                if name.find('tail') == -1:
                    raise KeyError('unexpected key "{}" in state_dict'
                                   .format(name))

        if strict:
            missing = set(own_state.keys()) - set(state_dict.keys())
            if len(missing) > 0:
                raise KeyError('missing keys in state_dict: "{}"'.format(missing))



# from option_du import args
# from torchviz import make_dot
# import graphviz
# net =Network(args).cuda()
# x=torch.randn(1, 1, 48, 48)
# out=net(x)
# vis_graph=make_dot(out)
# print(1111)
# # vis_graph.render('unet',view=True)
# vis_graph.view(