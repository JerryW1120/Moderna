from collections import namedtuple

Genotype = namedtuple('Genotype', 'normal normal_concat up up_concat down down_concat')
Genotype_multi = namedtuple('Genotype', 'normal_bottom normal_concat_bottom upsampling_bottom upsampling_concat_bottom \
                                         normal_mid normal_concat_mid upsampling_mid upsampling_concat_mid \
                                         normal_top normal_concat_top')

nq_N2_U4_C48_3_ch_depth_final = Genotype(normal=[('conv_3x3_no_bn', 0), ('resb', 1),('resb', 2), ('conv_3x3_no_bn', 3), ('sep_conv_5x5', 4), ('skip', 5),('conv_5x5_no_bn', 6), ('skip', 7),('resb', 8), ('conv_5x5_no_bn', 9), ('dil_conv_3x3', 10),('skip', 11), ('skip', 12), ('dil_conv_5x5', 13),('skip', 14), ('resb', 15), ('skip', 16), ('resb', 17),('resb', 18), ('resb', 19),('skip', 20)], normal_concat=[40, 40, 40, 32, 40, 40,40, 40, 40, 48, 48, 48, 40, 40, 40, 32, 32,32, 40, 40,40], up=[('bilinear_u', 0), ('bilinear_u', 1), ('bilinear_u', 2)], up_concat=[40, 40, 32], down=[('convolution_d', 0), ('nearest_d', 1), ('nearest_d', 2)], down_concat=[24, 32, 32])
