import torch
import  torch.nn.functional as F
import utility
import data
import model
import loss
from option_du import args
from trainer_search import Trainer
from arch import Arch

import time
import os
# torch.manual_seed(args.seed)
checkpoint = utility.checkpoint(args)
os.environ['CUDA_VISIBLE_DEVICES'] = '1'

def main():
    global model
    global loss

    if checkpoint.ok:
        loader = data.Data(args)
        share_model = model.Model(args, checkpoint)
        arch = Arch(share_model,args)
        loss = loss.Loss(args, checkpoint) if not args.test_only else None
        t = Trainer(args, loader, share_model, loss, checkpoint,arch)

        cur_epoch = 0
        while not t.terminate():
            epoch_time = time.time()
            # print(F.softmax(share_model.model.arch_alpha_normal, dim=-1).data.cpu().numpy())
            t.train()
            # if cur_epoch >= args.arch_start_training:
            #     arch_trainer_t.arch_train()
            t.test()
            cur_epoch+=1
            epoch_time = time.time() - epoch_time
            print('epochs time: {} h {} min '.format(int(epoch_time / 3600), epoch_time / 60),
                  ' total time: {} h {} min'.format(int(epoch_time * args.epochs / 3600),
                                                    epoch_time * args.epochs / 60 % 60))
        checkpoint.done()

if __name__ == '__main__':
    main()
