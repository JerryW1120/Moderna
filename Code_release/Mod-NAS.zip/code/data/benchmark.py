import os

from data import common
from data import srdata

import numpy as np

import torch
import torch.utils.data as data

class Benchmark(srdata.SRData):
    def __init__(self, args, name='', train=True, benchmark=True):
        super(Benchmark, self).__init__(
            args, name=name, train=train, benchmark=True
        )
        self.scale= args.scale
    def _set_filesystem(self, dir_data):
        self.apath = os.path.join(dir_data, 'benchmark', self.name)
        if self.name == 'Urban100':
            self.dir_hr = os.path.join(self.apath, 'HR','X4')
        else :
            self.dir_hr = os.path.join(self.apath, 'HR','X2')
        self.dir_lr = os.path.join(self.apath, 'HR','X2')
        self.ext = '.png'
        self.ext = ('', '.png')

