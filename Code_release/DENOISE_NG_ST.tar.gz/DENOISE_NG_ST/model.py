from __future__ import division
import os
import time
import scipy.signal
import scipy.io
import h5py
from glob import glob
import tensorflow as tf
#import matplotlib.pyplot as plt
import numpy as np
import scipy.misc

from ops import *
from utils import *


class SPCNN(object):
    def __init__(self, sess,is_train=True,N_GPU=2,batch_size=64,dataset_name='default', checkpoint_dir=None,):

        self.sess = sess
        self.batch_size = batch_size
        self.is_train = is_train
        self.N_GPU = N_GPU


        self.test_sample_size = batch_size  # choice test sample size
        self.dataset_name = dataset_name

        if self.is_train:
            self.image_shape = [50, 50, 10]

        else:
            self.image_shape = [300, 300, 31]
        # self.c_dim = 1

        self.checkpoint_dir = checkpoint_dir

        self.build_model()

        # self.lr = [0.001, 0.0001]
        # self.boudaries = [10]

    def build_model(self):
        """initialization the model"""

        self.input= tf.placeholder(tf.float32, [None,
                                                 self.image_shape[2],
                                                 self.image_shape[1],
                                                 self.image_shape[0],
                                                 1], name='noisy_images1')

        self.label = tf.placeholder(tf.float32, [None,
                                                 self.image_shape[2],
                                                 self.image_shape[1],
                                                 self.image_shape[0],
                                                 1], name='clean_images1')


        # create the Graph
        self.G = self.Unet(self.input)
        self.R = self.Unetr(self.input)


        self.g_loss = tf.reduce_mean(tf.square(self.label - self.G))
        self.g_loss2 = tf.reduce_mean(tf.square(self.label - self.R))

        self.g_loss_sum = tf.summary.scalar("g_loss", self.g_loss)

        t_vars = tf.trainable_variables()
        self.g_vars = [var for var in t_vars]


        self.saver = tf.train.Saver()
        self.writer = tf.summary.FileWriter("./logs", self.sess.graph)


    def prepare_data(self, key='train'):

        input_path = './data/' + self.dataset_name + '/' + key + '_input.mat'
        label_path = './data/' + self.dataset_name + '/' + key + '_label.mat'

        data_input_tmp = h5py.File(input_path)
        data_label_tmp = h5py.File(label_path)

        # create input data
        key_input = key + '_input'
        data_input_np = np.transpose(np.array(data_input_tmp[key_input]).astype(np.float32), [0, 1, 2])

        # create label data
        key_input = key + '_label'
        data_label_np = np.transpose(np.array(data_label_tmp[key_input]).astype(np.float32), [0, 1, 2])

        return data_input_np, data_label_np

    def prepare_data2(self, key='test'):#train,val

        input_path = './data/' + self.dataset_name + '/' + key + '_input.mat'
        label_path = './data/' + self.dataset_name + '/' + key + '_label.mat'

        data_input_tmp = h5py.File(input_path)
        data_label_tmp = h5py.File(label_path)

        data_input = data_input_tmp[key + '_input']
        data_label = data_label_tmp[key + '_label']

        return data_input, data_label

    # hyperspectral image part
    def train(self, config):
        g_optim = tf.train.AdamOptimizer(config.learning_rate).minimize(self.g_loss, var_list=self.g_vars)
        tf.global_variables_initializer().run()


        if self.load(self.checkpoint_dir):
            print(" [*] Load SUCCESS")
        else:
            print(" [!] Load failed...")

        counter = 1


        print("[prepare] loading train data...")
        train_input, train_label = self.prepare_data2('train')
        test_input, test_label = self.prepare_data2('val')
        train_size = train_input.shape[0]

        print("[INFO] the [%s] train dataset size is: %s" % (self.dataset_name, str(train_size)))
        start_time = time.time()

        # global_step = tf.Variable(tf.constant(0), trainable=False)
        # learning_rate = tf.train.piecewise_constant(global_step, boundaries=self.boudaries, values=self.lr)
        # g_optim = tf.train.AdamOptimizer(learning_rate).minimize(self.g_loss, var_list=self.g_vars)
        # tf.global_variables_initializer().run()
        # g_loss_best = 100

        for epoch in xrange(config.epoch):
            batch_idxs = min(train_size, config.train_size) // config.batch_size

            for idx in xrange(0, batch_idxs):

                batch_input_np = np.reshape(train_input[idx * config.batch_size:(idx + 1) * config.batch_size],list(train_input[idx * config.batch_size:(idx + 1) * config.batch_size].shape)+[1])
                batch_label_np = np.reshape(train_label[idx * config.batch_size:(idx + 1) * config.batch_size],list(train_label[idx * config.batch_size:(idx + 1) * config.batch_size].shape)+[1])
                # input_shape:[batch_size,spectral c,h,w,feature_c],[16,10,50,50,1]

                _, _, loss = self.sess.run([g_optim, self.G, self.g_loss], feed_dict={self.input: batch_input_np, self.label: batch_label_np})
                # _, _, loss = self.sess.run([g_optim, self.G, self.g_loss],
                #                            feed_dict={self.input: batch_input_np, self.label: batch_label_np,
                #                                       global_step: epoch})

                counter += 1

                if idx == 0:
                    test_input_np = np.reshape(test_input[idx * config.batch_size:(idx + 1) * config.batch_size],list(test_input[idx * config.batch_size:(idx + 1) * config.batch_size].shape) + [1])
                    test_label_np = np.reshape(test_label[idx * config.batch_size:(idx + 1) * config.batch_size], list(test_label[idx * config.batch_size:(idx + 1) * config.batch_size].shape)+[1])

                    _, g_loss = self.sess.run([self.G, self.g_loss], feed_dict={self.input: test_input_np, self.label: test_label_np})

                if np.mod(counter, 500) == 0:
                    self.save(config.checkpoint_dir, counter)

                # if g_loss < g_loss_best:
                #     self.save(config.checkpoint_dir, counter)
                #     g_loss_best = g_loss

            print("[Test] Epoch: [%2d] time: %4.4f, train_loss: %.8f,test_loss: %.8f" % (epoch + 1, time.time() - start_time, loss, g_loss))


    def Unet(self, z):
        """define net"""
        z0, self.z0_w, self.z0_b = conv3d(z, 64,f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="trans0", with_w=True)
        z0 = relu(z0)
        ##Enconding
        f0, down0 = self.enconding_block(z0,name='encoding_0')
        f1, down1 = self.enconding_block(down0, name='encoding_1')
        f2, down2 = self.enconding_block(down1, name='encoding_2')

        #decoding
        deco2 = self.deconding_block(f2, down2, name='decoding_2')
        deco1 = self.deconding_block(f1, deco2, name='decoding_1')
        deco0 = self.deconding_block(f0, deco1, name='decoding_0')

        out = conv3d(deco0, 1, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="trans1")
        out = out+z

        return out

    def Unetr(self, x):
        """define net"""

        # with tf.variable_scope("block"):
        z0, self.z0_w, self.z0_b = conv3d_r(x, 64, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="trans0", with_w=True)
        z0 = relu(z0)
        ##Enconding1
        f0, down0 = self.enconding_block_r(z0, name='encoding_0')
        f1, down1 = self.enconding_block_r(down0, name='encoding_1')
        f2, down2 = self.enconding_block_r(down1, name='encoding_2')
        # f3, down3 = self.enconding_block(down2, name='encoding_3')

        deco2 = self.deconding_block_r(f2, down2, name='decoding_2')
        deco1 = self.deconding_block_r(f1, deco2, name='decoding_1')
        deco0 = self.deconding_block_r(f0, deco1, name='decoding_0')

        # out = deco0+z0
        # out = conv3d(out, 1, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="trans1")
        out = conv3d_r(deco0, 1, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="trans1")

        ##tj
        # out = relu(out)
        out = out + x
        return out

    def enconding_block(self, e, name):
        with tf.variable_scope(name):
            for i in range(5):
                # e, self.e_w, self.e_b = conv3d(e, 64, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="enBlock_trans_%d" %i, with_w=True)
                # e = relu(e)

                e1, self.e1_w, self.e1_b = conv3d(e, 64, f_d=1, f_h=3, f_w=3, d_f=1, d_h=1, d_w=1, name="enBlock_2d_%d" %i, with_w=True)
                e1 = relu(e1)

                e2, self.e2_w, self.e2_b = conv3d(e, 64, f_d=3, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="enBlock_1d_%d" %i, with_w=True)
                e2 = relu(e2)

                e3 = tf.concat([e1, e2], axis=4)

                e3, self.e3_w, self.e3_b = conv3d(e3, 64, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="resBlock_down_%d" %i, with_w=True)
                e3 = relu(e3)

                e = e3 + e

            down = conv3d(e, 64, f_d=1, f_h=3, f_w=3, d_f=1, d_h=2, d_w=2, name="down_sampling")

        return e, down

    def deconding_block(self, f,d, name):
        with tf.variable_scope(name):
            d, self.d_w, self.d_b = deconv3d(d, [self.batch_size,int(f.get_shape()[1]),int(f.get_shape()[2]),int(f.get_shape()[3]),64],
                                           f_d=1, f_h=4, f_w=4, d_f=1, d_h=2, d_w=2, name="upsample", with_w=True)
            d = relu(d)

            d = tf.concat([f, d], axis=4)

            d1, self.d1_w, self.d1_b = conv3d(d, 64, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="deBlock_trans0", with_w=True)
            d1 = relu(d1)

            for i in range(5):

                d2, self.d2_w, self.d2_b = conv3d(d1, 64, f_d=3, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="deBlock_1d_%d" %i, with_w=True)
                d2 = relu(d2)

                d3, self.d3_w, self.d3_b = conv3d(d1, 64, f_d=1, f_h=3, f_w=3, d_f=1, d_h=1, d_w=1, name="deBlock_2d_%d" %i,with_w=True)
                d3 = relu(d3)

                d4 = tf.concat([d2, d3], axis=4)

                d4, self.d4_w, self.d4_b = conv3d(d4, 64, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1,name="deBlock_trans1_%d" %i, with_w=True)
                d4 = relu(d4)

                d1 = d4 + d1

        return d1

    def enconding_block_r(self, e, name):
        with tf.variable_scope(name):
            for i in range(5):
                # e, self.e_w, self.e_b = conv3d(e, 64, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="enBlock_trans_%d" %i, with_w=True)
                # e = relu(e)

                e1, self.e1_w, self.e1_b = conv3d_r(e, 64, f_d=1, f_h=3, f_w=3, d_f=1, d_h=1, d_w=1,
                                                    name="enBlock_2d_%d" % i, with_w=True)
                e1 = relu(e1)

                e2, self.e2_w, self.e2_b = conv3d_r(e, 64, f_d=3, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1,
                                                    name="enBlock_1d_%d" % i, with_w=True)
                e2 = relu(e2)

                e3 = tf.concat([e1, e2], axis=4)

                e3, self.e3_w, self.e3_b = conv3d_r(e3, 64, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1,
                                                    name="resBlock_down_%d" % i, with_w=True)
                e3 = relu(e3)

                e = e3 + e

            down = conv3d_r(e, 64, f_d=1, f_h=3, f_w=3, d_f=1, d_h=2, d_w=2, name="down_sampling")
            ##tj
            # down = relu(down)

        return e, down

    def deconding_block_r(self, f, d, name):
        with tf.variable_scope(name):
            d, self.d_w, self.d_b = deconv3d_r(d, [self.batch_size, int(f.get_shape()[1]), int(f.get_shape()[2]),
                                                   int(f.get_shape()[3]), 64],
                                               f_d=1, f_h=4, f_w=4, d_f=1, d_h=2, d_w=2, name="upsample", with_w=True)
            d = relu(d)

            d = tf.concat([f, d], axis=4)

            d1, self.d1_w, self.d1_b = conv3d_r(d, 64, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1, name="deBlock_trans0",
                                                with_w=True)
            d1 = relu(d1)

            for i in range(5):
                d2, self.d2_w, self.d2_b = conv3d_r(d1, 64, f_d=3, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1,
                                                    name="deBlock_1d_%d" % i, with_w=True)
                d2 = relu(d2)

                d3, self.d3_w, self.d3_b = conv3d_r(d1, 64, f_d=1, f_h=3, f_w=3, d_f=1, d_h=1, d_w=1,
                                                    name="deBlock_2d_%d" % i, with_w=True)
                d3 = relu(d3)

                d4 = tf.concat([d2, d3], axis=4)

                d4, self.d4_w, self.d4_b = conv3d_r(d4, 64, f_d=1, f_h=1, f_w=1, d_f=1, d_h=1, d_w=1,
                                                    name="deBlock_trans1_%d" % i, with_w=True)
                d4 = relu(d4)

                d1 = d4 + d1

                # down = conv3d(e3, 64, f_d=1, f_h=3, f_w=3, d_f=1, d_h=2, d_w=2, name="down_sampling")

        return d1


    def test(self, config):
        """Test SPCNN"""

        if self.load2(self.checkpoint_dir):
            print(" [*] Load SUCCESS")
        else:
            print(" [!] Load failed...")

        test_out_lst = []
        loss = 0
        test_input, test_label = self.prepare_data2('test')
        print('[INFO] [test] starting test...')
        start_time = time.clock()
        for idx in xrange(0, 4):

            test_input_np = np.reshape(test_input[idx * config.batch_size:(idx + 1) * config.batch_size], list(test_input[idx * config.batch_size:(idx + 1) * config.batch_size].shape) + [1])
            test_label_np = np.reshape(test_label[idx * config.batch_size:(idx + 1) * config.batch_size], list(test_label[idx * config.batch_size:(idx + 1) * config.batch_size].shape) + [1])
            #input_shape:[batch_size,spectral c,h,w,feature_c],[1,31,300,300,1]


        # test_input_np = np.reshape(test_input, list(test_input.shape) + [1])
        # test_label_np = np.reshape(test_label, list(test_label.shape) + [1])


            middle, loss = self.sess.run([self.R,self.g_loss2],feed_dict={self.input: test_input_np,self.label:test_label_np})

            loss += loss

            test_out_lst.append(middle)

        print("[INFO] [test] test finished, cost time is: %.4f, loss is: %.8f" % (time.clock() - start_time,loss))
        save_path = './data/' + config.dataset + '/sfcnn_result.mat'

        scipy.io.savemat(save_path, {'sfcnn_result': test_out_lst})

    def save(self, checkpoint_dir, step):
        model_name = "SPCNN"
        model_dir = "%s_%s" % (self.dataset_name, self.batch_size)
        checkpoint_dir = os.path.join(checkpoint_dir, model_dir)

        if not os.path.exists(checkpoint_dir):
            os.makedirs(checkpoint_dir)

        self.saver.save(self.sess, os.path.join(checkpoint_dir, model_name), global_step=step)

    def load(self, checkpoint_dir):
        print(" [*] Reading checkpoints...")

        model_dir = "%s_%s" % (self.dataset_name, self.batch_size)
        checkpoint_dir = os.path.join(checkpoint_dir, model_dir)

        ckpt = tf.train.get_checkpoint_state(checkpoint_dir)
        if ckpt and ckpt.model_checkpoint_path:
            ckpt_name = os.path.basename(ckpt.model_checkpoint_path)
            self.saver.restore(self.sess, os.path.join(checkpoint_dir, ckpt_name))
            return True
        else:
            return False

    def load2(self, checkpoint_dir):
        print(" [*] Reading checkpoints...")

        model_dir = "%s_%s" % (self.dataset_name, 16)
        checkpoint_dir = os.path.join(checkpoint_dir, model_dir)

        ckpt = tf.train.get_checkpoint_state(checkpoint_dir)
        if ckpt and ckpt.model_checkpoint_path:
            ckpt_name = os.path.basename(ckpt.model_checkpoint_path)
            self.saver.restore(self.sess, os.path.join(checkpoint_dir, ckpt_name))
            return True
        else:
            return False

