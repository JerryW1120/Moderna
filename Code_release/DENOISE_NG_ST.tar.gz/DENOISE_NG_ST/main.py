import os
import numpy as np

from model import SPCNN
from utils import pp, visualize, to_json
os.environ["CUDA_VISIBLE_DEVICES"]="1"

import tensorflow as tf

flags = tf.app.flags
flags.DEFINE_integer("epoch", 30, "Epoch to train [25]")
flags.DEFINE_integer("N_GPU", 2, "Epoch to train [25]")
flags.DEFINE_float("learning_rate", 0.001, "Learning rate of for adam [0.0002]")
flags.DEFINE_integer("train_size", np.inf, "The size of train images [np.inf]")
flags.DEFINE_integer("batch_size",16, "The size of batch images [16],[1] for test ")
flags.DEFINE_string("dataset", "CAVE", "The name of dataset")
flags.DEFINE_string("checkpoint_dir", "checkpoint", "Directory name to save the checkpoints [checkpoint]")
flags.DEFINE_string("sample_dir", "samples", "Directory name to save the image samples [samples]")
flags.DEFINE_boolean("is_train",True, "True for training1, False for testing [False]")
FLAGS = flags.FLAGS


def main(_):
    pp.pprint(flags.FLAGS.__flags)

    if not os.path.exists(FLAGS.checkpoint_dir):
        os.makedirs(FLAGS.checkpoint_dir)
    if not os.path.exists(FLAGS.sample_dir):
        os.makedirs(FLAGS.sample_dir)
    # if not os.path.exists(FLAGS.checkpoint_dir2):
    #     os.makedirs(FLAGS.checkpoint_dir2)

    with tf.Session() as sess:
        # with tf.device("/gpu:0"):
        if FLAGS.dataset == 'CAVE':
            spcnn = SPCNN(sess, is_train=FLAGS.is_train,N_GPU=FLAGS.N_GPU, batch_size=FLAGS.batch_size,
                          dataset_name=FLAGS.dataset,checkpoint_dir=FLAGS.checkpoint_dir,)
        else:
            print ""
            spcnn = None

        if FLAGS.is_train:
            spcnn.train(FLAGS)

        else:
            spcnn.test(FLAGS)


if __name__ == '__main__':
    tf.app.run()

