Note: Our implementation is based on pytorch_0.4.0 and for accessibility of our code, please place the .py file from the modules folder in the pytorch library:*** \torch\nnnn\modules and replace the original file.



If you have any questions, please contact us at xiaotonglu47@gmail.com or wsdong@mail.xidian.edu.cn. 

If our work is cited, please mark the citation as:


@inproceedings{lu2020beyond,
  title={Beyond network pruning: a joint search-and-training approach},
  author={Lu, Xiaotong and Huang, Han and Dong, Weisheng and Li, Xin and Shi, Guangming},
  booktitle={International Joint Conference on Artificial Intelligence},
  year={2020}
}