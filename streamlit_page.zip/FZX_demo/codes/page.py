import streamlit as st
import numpy as np
import cv2
import os
import torch
from streamlit_image_comparison import image_comparison

from test_real import test_real

st.title('ECCV 2022 Uncertainty learning in kernel estimation for multi-stage blind image super-resolution')
st.write('This is a demo for the paper "Uncertainty learning in kernel estimation for multi-stage blind image super-resolution"')

st.write('Please upload your image')
uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])
print('uploaded_file is:', uploaded_file)

if uploaded_file is not None:
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("### Original Image")
        # 获取 uploaded_file的信息
        file_details = {"FileName": uploaded_file.name, "FileType": uploaded_file.type, "FileSize": uploaded_file.size}
        # st.write(file_details)
        image = uploaded_file.read()

        # 清除 inference/images文件夹下的所有文件
        existed_files = os.listdir('../datasets/demo')
        for file in existed_files:
            os.remove('../datasets/demo/' + file)

        # 将上传的图片保存到 inference/images文件夹下
        file_bytes = np.asarray(bytearray(image), dtype="uint8")
        opencv_image = cv2.imdecode(file_bytes, 1)
        cv2.imwrite('../datasets/demo/' + uploaded_file.name, opencv_image)

        # 在网页中显示上传的图片
        st.image(image, caption='Uploaded Image.', use_column_width=True)
        st.write("")

    with col2:
        st.markdown("### SR Image")
        # 进行超分辨率
        with torch.no_grad():
            test_real()

        # 在网页中显示超分辨率后的图片

        sr_image = cv2.imread('../results/test_real_x4/demo/' + uploaded_file.name)
        st.image(sr_image, caption='Super-Resolution Image.', use_column_width=True, channels="BGR")
        st.write("")


    st.markdown("### Let's compare")
    image_comparison(
        img1=os.path.join('../datasets/demo/' + uploaded_file.name),
        img2=os.path.join('../results/test_real_x4/demo', uploaded_file.name),
        label1="LR",
        label2="SR",
    )